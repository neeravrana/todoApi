var express = require('express'),
  app = express(),
  port = process.env.PORT || 3000,
  mongoose = require('mongoose'),
  Task = require('./api/models/todoListModel'), //created model loading here
  bodyParser = require('body-parser');
  
// mongoose instance connection url connection
mongoose.Promise = global.Promise;
 
// mongoose.model('Test,new Schema({})');

app.use(bodyParser.urlencoded({ extended: true }));



var routes = require('./api/routes/todoListRoutes'); //importing route
routes(app); //register the route




mongoose.connect('mongodb+srv://Neerav:ECLjvjzLXbd4ua4n@clusterpractice-hpe1p.mongodb.net/test?retryWrites=true&w=majority',{useNewUrlParser: true}).then(
    result=>{
        app.listen(port);
    }
).catch(err=>{
    console.log(err)
})
console.log('todo list RESTful API server started on: ' + port);